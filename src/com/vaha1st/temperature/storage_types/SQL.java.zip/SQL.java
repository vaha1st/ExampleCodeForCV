package com.vaha1st.temperature.storage_types;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.sql.*;

import static java.sql.DriverManager.getConnection;

@Component
public class SQL implements Storage {

    // Для подключения к БД в вашей системе, необходимо изменить эти 4 переменных на соответствующие.
    final String DB_DRIVER = "oracle.jdbc.driver.OracleDriver";
    final String DB_URL = "jdbc:oracle:thin:@localhost:1521:XE";
    final String DB_USER = "admin";
    final String DB_PASSWORD = "admin";

    // Создание пустых SQL подключения, сообщения и результатов запроса.
    private static Connection connection = null;
    private static Statement statement = null;
    private static ResultSet resultSet = null;

    @Override
    @Autowired
    public void process() {

        try {
            //Регистрация драйвера
            Class.forName(DB_DRIVER);

            //Подключение к локальной БД Oracle Database 18c Express Edition
            connection = getConnection(DB_URL, DB_USER, DB_PASSWORD);

            //Переменная для запросов SQL
            statement = connection.createStatement();

            //Запрос в БД на создание таблицы
            statement.executeUpdate("CREATE TABLE history" +
                    "(id number primary key," +
                    "input_date date," +
                    "input_value number(29,9)," +
                    "input_unit varchar2(4)," +
                    "output_value number(29,9)," +
                    "output_unit varchar2(4))");

            //Запрос в БД на создание стандартной последовательности
            statement.executeUpdate("CREATE SEQUENCE history_id");

            //Обработка ошибок синтаксиса SQL запроса.
        } catch (SQLSyntaxErrorException e) {
            if (e.getMessage().contains("ORA-00955")) {                 //Игнорировать "таблица уже существует"
            } else {
                e.printStackTrace();                                    //Вывод других ошибок
            }
        } catch (ClassNotFoundException e) {
            System.out.println("Драйвер не найден");
            e.printStackTrace();
        } catch (SQLException e) {
            System.out.println("Не удается подключиться к базе данных");
            e.printStackTrace();
        } finally {

            try {
                //Запрос в БД на запись в таблицу history строки данных текущей конвертации
                statement.executeUpdate("INSERT INTO history values " +
                        "(history_id.nextval, SYSDATE, " + run.getInput().getValue() + ", '" +
                        run.getInput().getInUnit().getUnit() + "', " +
                        run.getResult() + ", '" + run.getInput().getOutUnit().getUnit() + "')");
                //Принудительное сохранение сессии.
                statement.executeUpdate("COMMIT");

            } catch (SQLException e) {
                e.printStackTrace();
            } finally {
                // Освобождение ресурсов, если заняты.
                exit();
            }
        }
    }


        @Override
        public void exit () {
            //Если был вызван выход, очищаются ресурсы и завершается программа.
            try {
                if (resultSet != null)
                    resultSet.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
            try {
                if (statement != null)
                    statement.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
            try {
                if (connection != null)
                    connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
            System.exit(0);
        }

        @Override
        public void clear () {
            try {
                statement.executeUpdate("TRUNCATE TABLE history");   //Очистка таблицы с историей по запросу
                statement.executeUpdate("DROP SEQUENCE history_id"); //Сброс последовательности
            } catch (SQLException e) {
                e.printStackTrace();
            }

        }

        @Override
        public void history () {
            System.out.println("Сохраненная история:");
            try {
                resultSet = statement.executeQuery("SELECT id, to_char(input_date, 'dd.mm.yy hh:mi') as " +
                        "date_and_time, input_value, input_unit, output_value, output_unit FROM HISTORY" +
                        " order by id");
                System.out.println("__________________________________________________________________________________________________");
                System.out.println("|ID |      Time      |      Input Value      | Input Unit |      Output Value      | Output Unit |");
                System.out.println("|___|________________|_______________________|____________|________________________|_____________|");
                while (resultSet.next()) {
                    int tableID = resultSet.getInt(1);
                    String dateTime = resultSet.getString(2);
                    double inVal = resultSet.getDouble(3);
                    String inUnit = resultSet.getString(4);
                    double outVal = resultSet.getDouble(5);
                    String outUnit = resultSet.getString(6);
                    System.out.printf("|%3d|%16s|%23.3f|%12s|%24.3f|%13s|%n",
                            tableID, dateTime, inVal, inUnit, outVal, outUnit);
                }
                System.out.println("__________________________________________________________________________________________________");
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
